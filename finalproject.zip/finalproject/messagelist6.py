"""Get a list of Messages from the user's mailbox."""
from apiclient import errors
import httplib2
import os
from apiclient import discovery
import oauth2client
from oauth2client import client
from oauth2client import tools
import base64
import email
from apiclient import errors
import operator
from itertools import islice
from flask import Flask
from flask import redirect, render_template, request, session
from functools import wraps
import base64
import math
import logging
from oauth2client.client import flow_from_clientsecrets
from oauth2client.client import FlowExchangeError
from apiclient.discovery import build
from apiclient.discovery import build

# From GMAIL API
def build_service(credentials):
  """Build a Gmail service object.

  Args:
    credentials: OAuth 2.0 credentials.

  Returns:
    Gmail service object.
  """
  http = httplib2.Http()
  http = credentials.authorize(http)
  return build('gmail', 'v1', http=http)

SCOPES = 'https://mail.google.com/'
CLIENT_SECRET_FILE = 'client_secret6.json'
APPLICATION_NAME = 'Gmail API Quickstart'

# From GMAIL API
def GetMessage(service, user_id, msg_id):
  """Get a Message with given ID.

  Args:
    service: Authorized Gmail API service instance.
    user_id: User's email address. The special value "me"
    can be used to indicate the authenticated user.
    msg_id: The ID of the Message required.

  Returns:
    A Message.
  """
  try:
    message = service.users().messages().get(userId=user_id, id=msg_id).execute()
    return message
  except errors.HttpError, error:
    print 'An error occurred: %s' % error

# From GMAIL API
def GetMimeMessage(service, user_id, msg_id):
  """Get a Message and use it to create a MIME Message.

  Args:
    service: Authorized Gmail API service instance.
    user_id: User's email address. The special value "me"
    can be used to indicate the authenticated user.
    msg_id: The ID of the Message required.

  Returns:
    A MIME Message, consisting of data from Message.
  """
  try:
    message = service.users().messages().get(userId=user_id, id=msg_id,
                                             format='raw').execute()
    msg_str = base64.urlsafe_b64decode(message['raw'].encode('ASCII'))
    #print(msg_str)
    mime_msg = email.message_from_string(msg_str)

    return mime_msg
  except errors.HttpError, error:
    print 'An error occurred: %s' % error

# From GMAIL API
def get_credentials():
  """Gets valid user credentials from storage.

  If nothing has been stored, or if the stored credentials are invalid,
  the OAuth2 flow is completed to obtain the new credentials.

  Returns:
      Credentials, the obtained credential.
  """
  home_dir = os.path.expanduser('~')
  credential_dir = os.path.join(home_dir, '.credentials')
  if not os.path.exists(credential_dir):
      os.makedirs(credential_dir)
  credential_path = os.path.join(credential_dir,
                                 'gmail-quickstart.json')

  store = oauth2client.file.Storage(credential_path)
  credentials = store.get()
  flow = client.flow_from_clientsecrets(CLIENT_SECRET_FILE, SCOPES)
  flow.user_agent = APPLICATION_NAME
  credentials = tools.run_flow(flow, store)
  print 'Storing credentials to ' + credential_path
  return credentials


# Gets the body of a message
# Code is borrowed from chmod750 from StackOverflow
# https://stackoverflow.com/users/5215684/chmod750
def GetMessageBody(service, user_id, msg_id):
    try:
            message = service.users().messages().get(userId=user_id, id=msg_id, format='raw').execute()
            msg_str = base64.urlsafe_b64decode(message['raw'].encode('ASCII'))
            mime_msg = email.message_from_string(msg_str)
            messageMainType = mime_msg.get_content_maintype()
            if messageMainType == 'multipart':
                    for part in mime_msg.get_payload():
                            if part.get_content_maintype() == 'text':
                                    return part.get_payload()
                    return ""
            elif messageMainType == 'text':
                    return mime_msg.get_payload()
    except errors.HttpError, error:
            print 'An error occurred: %s' % error

# Determines whether the message body needs to be decoded or not and returns the decoded message body
# Adapted from StackOverflow user Stephan202
# https://stackoverflow.com/questions/1532567/given-a-string-how-do-i-know-if-it-needs-decoding
def decode_if_necessary(s):
    if s.find(" ") == -1:
      return base64.decodestring(s)
    return s

# From GMAIL API
def ListMessagesMatchingQuery(service, user_id, query=''):
  """List all Messages of the user's mailbox matching the query.

  Args:
    service: Authorized Gmail API service instance.
    user_id: User's email address. The special value "me"
    can be used to indicate the authenticated user.
    query: String used to filter messages returned.
    Eg.- 'from:user@some_domain.com' for Messages from a particular sender.

  Returns:
    List of Messages that match the criteria of the query. Note that the
    returned list contains Message IDs, you must use get with the
    appropriate ID to get the details of a Message.
  """
  try:
    response = service.users().messages().list(userId=user_id,
                                               q=query).execute()
    messages = []
    if 'messages' in response:
      messages.extend(response['messages'])

    while 'nextPageToken' in response:
      page_token = response['nextPageToken']
      response = service.users().messages().list(userId=user_id, q=query,
                                         pageToken=page_token).execute()
      messages.extend(response['messages'])

    return messages
  except errors.HttpError, error:
    print 'An error occurred: %s' % error

# From GMAIL API
def ListMessagesWithLabels(service, user_id, label_ids=[]):
  """List all Messages of the user's mailbox with label_ids applied.

  Args:
    service: Authorized Gmail API service instance.
    user_id: User's email address. The special value "me"
    can be used to indicate the authenticated user.
    label_ids: Only return Messages with these labelIds applied.

  Returns:
    List of Messages that have all required Labels applied. Note that the
    returned list contains Message IDs, you must use get with the
    appropriate id to get the details of a Message.
  """
  try:
    response = service.users().messages().list(userId=user_id,
                                               labelIds=label_ids).execute()
    messages = []
    if 'messages' in response:
      messages.extend(response['messages'])

    while 'nextPageToken' in response:
      page_token = response['nextPageToken']
      response = service.users().messages().list(userId=user_id,
                                                 labelIds=label_ids,
                                                 pageToken=page_token).execute()
      messages.extend(response['messages'])

    return messages
  except errors.HttpError, error:
    print 'An error occurred: %s' % error


#### The below code is original code that we wrote ourselves#####

# Determines if the given sender already exists in the dictionary
def inDictionary(sender, dictionary):
  for key in dictionary:
    if key == sender:
      return True
  return False

# Determines the location in the Message list where the desired field is located
# i.e. the index of the desired field (e.g. "From", "Date", etc.) 
def indexInMessage(message, field):
  for i in range(0,len(message)):
    if (field == message[i]['name']):
      return i
  print 'An error occurred'
  return -55
  

# Compile a dictionary that contains unique sender names and the number of times that each sender 
# sent you an email.
credentials = build_service(get_credentials())

messages = ListMessagesMatchingQuery(credentials, "me")
emailCounts = {}
for message in messages:
  curr = GetMessage(credentials, "me", message['id'])
  #print("Message has been acquired")
  index = indexInMessage(curr['payload']['headers'], "From")
  sender = curr['payload']['headers'][index]['value']
  if "<" in sender:
    sender = sender[sender.index("<")+1:sender.index(">")].lower()
  if not inDictionary(sender, emailCounts):
    emailCounts.update({sender: 1})
  else:
    emailCounts[sender] = emailCounts[sender] + 1


# Determines the sender who has sent you the most emails, as well as that maximum number of emails.
def findMaxSender():
  maxSender = ""
  maxEmails = 0 
  for key in emailCounts:
    if emailCounts[key] > maxEmails:
      maxSender = key  
      maxEmails = emailCounts[key]
  return maxSender

# Sorts emailCounts dictionary by number of emails sent
def sortedEmails():
  sortedEmailCounts = sorted(emailCounts.items(), key=operator.itemgetter(1), reverse = True)
  return sortedEmailCounts

# Gets a list of the top 20% of senders by number of emails sent
def findTopFifth():
  topFifth = {}
  numTopFifth = len(emailCounts)//5
  #sortedEmailCounts = sorted(emailCounts.items(), key=operator.itemgetter(1), reverse = True)
  topFifth = sortedEmails()[0:numTopFifth]
  return topFifth

# Sums the total number of emails that the top 20% of senders have sent you
def sumTopFifth():
  sumTopFifthCounts = 0
  for i in range(len(emailCounts)//5):
    sumTopFifthCounts += findTopFifth()[i][1]
  return sumTopFifthCounts

# Sums the total number of emails in your inbox
def sumEmails():
  totalEmails = 0
  for i in range(len(sortedEmails())):
    totalEmails += sortedEmails()[i][1]
  return totalEmails

# Calculates the percentage of your inbox that is occupied by messages sent by the top fifth of senders
def findPercentTopFifth():
  percentOccupiedByTopFifth = float(sumTopFifth())/sumEmails() * 100
  return percentOccupiedByTopFifth
  #print (percentOccupiedByTopFifth)

# Finds the average size of all messages in inbox in bytes
def findAverageSizeOfMessageInBytes(): 
  totalSize = 0.0
  for message in messages:
    curr = GetMessage(credentials, "me", message['id'])
    totalSize += curr['sizeEstimate']
  averageSize = float(totalSize)/sumEmails()
  return averageSize

# Finds the average size of all messages in inbox in kilobytes
def findAverageSizeOfMessageInKB():
  return round(findAverageSizeOfMessageInBytes()/1024, 2)

# Finds the average number of words per email message in the inbox
# Excludes messages where the entire content of the email is an HTML file, rather than text
# Also excludes messages with random tags that usually denote some non-textual content yet make the message appear to contain far more words than it actually contains
def averageWordCount(): 
  sumWords = 0
  numEmails = 0
  for message in messages:
    curr = GetMessageBody(credentials, "me", message['id'])
    decoded = decode_if_necessary(curr)
    if decoded.find("<!DOCTYPE") == -1 and decoded.find("=0A") == -1:
        sumWords += decoded.count(' ')
        numEmails = numEmails + 1
  avg = float(sumWords)/numEmails
  newavg = round(avg, 2)
  return newavg