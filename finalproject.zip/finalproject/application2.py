from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions
from werkzeug.security import check_password_hash, generate_password_hash
import google.oauth2.credentials
import google_auth_oauthlib.flow
import googleapiclient.discovery
import httplib2
import os
from apiclient import discovery
import oauth2client
from oauth2client import client
from oauth2client import tools
import base64
import email
from apiclient import errors
import operator
import base64
from oauth2client.client import flow_from_clientsecrets, FlowExchangeError
from apiclient.discovery import build
import matplotlib.pyplot as plt; plt.rcdefaults()
import matplotlib.pyplot as plt, mpld3
import random


# Configure application
app = Flask(__name__)


# Configure session to use filesystem (instead of signed cookies)
app.config['DEBUG'] = True
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
app.config["TEMPLATES_AUTO_RELOAD"] = True
Session(app)

# Renders the index.html template
@app.route("/")
def index():
	return render_template("index.html")

# Handles the datavis route, eventually rendering the datavis.html template
@app.route("/datavis")
def datavis():
  # From GMAIL API
  def build_service(credentials):
    
    http = httplib2.Http()
    http = credentials.authorize(http)
    return build('gmail', 'v1', http=http)

  SCOPES = 'https://mail.google.com/'
  CLIENT_SECRET_FILE = 'client_secret6.json'
  APPLICATION_NAME = 'Gmail API Quickstart'

  
  # Get a Message with given ID.
  # Args:
  #    service: Authorized Gmail API service instance.
  #    user_id: User's email address. The special value "me"
  #    can be used to indicate the authenticated user.
  #    msg_id: The ID of the Message required.

  # Returns:
  #  A Message.

  # From GMAIL API
  def GetMessage(service, user_id, msg_id):
    try:
      message = service.users().messages().get(userId=user_id, id=msg_id).execute()
      return message
    except errors.HttpError, error:
      print 'An error occurred: %s' % error

  # Gets valid user credentials from storage.
  # If nothing has been stored, or if the stored credentials are invalid,
  # the OAuth2 flow is completed to obtain the new credentials.
  # Returns:
        #Credentials, the obtained credential.

  # From GMAIL API
  def get_credentials():
    
    home_dir = os.path.expanduser('~')
    credential_dir = os.path.join(home_dir, '.credentials')
    if not os.path.exists(credential_dir):
        os.makedirs(credential_dir)
    credential_path = os.path.join(credential_dir,
                                   'gmail-quickstart.json')

    store = oauth2client.file.Storage(credential_path)
    credentials = store.get()
    flow = client.flow_from_clientsecrets(CLIENT_SECRET_FILE, SCOPES)
    flow.user_agent = APPLICATION_NAME
    credentials = tools.run_flow(flow, store)
    return credentials


  # Gets the body of a message
  # Code is borrowed from chmod750 from StackOverflow
  # https://stackoverflow.com/users/5215684/chmod750
  def GetMessageBody(service, user_id, msg_id):
      try:
              message = service.users().messages().get(userId=user_id, id=msg_id, format='raw').execute()
              msg_str = base64.urlsafe_b64decode(message['raw'].encode('ASCII'))
              mime_msg = email.message_from_string(msg_str)
              messageMainType = mime_msg.get_content_maintype()
              if messageMainType == 'multipart':
                      for part in mime_msg.get_payload():
                              if part.get_content_maintype() == 'text':
                                      return part.get_payload()
                      return ""
              elif messageMainType == 'text':
                      return mime_msg.get_payload()
      except errors.HttpError, error:
              print 'An error occurred: %s' % error

  # Determines whether the message body needs to be decoded or not and returns the decoded message body
  # Adapted from StackOverflow user Stephan202
  # https://stackoverflow.com/questions/1532567/given-a-string-how-do-i-know-if-it-needs-decoding
  def decode_if_necessary(s):
    try:
      if s.find(" ") == -1:
        missing_padding = len(s) % 4
        if missing_padding != 0:
          s += '='* (4 - missing_padding)
        return base64.decodestring(s)
    except:
      return s

  # List all Messages of the user's mailbox matching the query.

  # Args:
  #    service: Authorized Gmail API service instance.
  #    user_id: User's email address. The special value "me"
  #    can be used to indicate the authenticated user.
  #    query: String used to filter messages returned.
  #    Eg.- 'from:user@some_domain.com' for Messages from a particular sender.

  # Returns:
  #    List of Messages that match the criteria of the query. Note that the
  #    returned list contains Message IDs, you must use get with the
  #    appropriate ID to get the details of a Message.

  # From GMAIL API
  def ListMessagesMatchingQuery(service, user_id, query=''):
    
    try:
      response = service.users().messages().list(userId=user_id,
                                                 q=query).execute()
      messages = []
      if 'messages' in response:
        messages.extend(response['messages'])

      while 'nextPageToken' in response:
        page_token = response['nextPageToken']
        response = service.users().messages().list(userId=user_id, q=query,
                                           pageToken=page_token).execute()
        messages.extend(response['messages'])

      return messages
    except errors.HttpError, error:
      print 'An error occurred: %s' % error

  # List all Messages of the user's mailbox with label_ids applied.

  # Args:
  #    service: Authorized Gmail API service instance.
  #    user_id: User's email address. The special value "me"
  #    can be used to indicate the authenticated user.
  #    label_ids: Only return Messages with these labelIds applied.

  # Returns:
  #    List of Messages that have all required Labels applied. Note that the
  #    returned list contains Message IDs, you must use get with the
  #    appropriate id to get the details of a Message.

  # From GMAIL API
  def ListMessagesWithLabels(service, user_id, label_ids=[]):
    
    try:
      response = service.users().messages().list(userId=user_id,
                                                 labelIds=label_ids).execute()
      messages = []
      if 'messages' in response:
        messages.extend(response['messages'])

      while 'nextPageToken' in response:
        page_token = response['nextPageToken']
        response = service.users().messages().list(userId=user_id,
                                                   labelIds=label_ids,
                                                   pageToken=page_token).execute()
        messages.extend(response['messages'])

      return messages
    except errors.HttpError, error:
      print 'An error occurred: %s' % error

#The below code is original code that we wrote ourselves

  # Determines if the given sender already exists in the dictionary
  def inDictionary(sender, dictionary):
    for key in dictionary:
      if key == sender:
        return True
    return False

  # Determines the location in the Message list where the desired field is located
  # i.e. the index of the desired field (e.g. "From", "Date", etc.) 
  def indexInMessage(message, field):
    for i in range(0,len(message)):
      if (field == message[i]['name']):
        return i
    print 'An error occurred'
    return -55
    
  # Compile a dictionary that contains unique sender names and the number of times that each sender 
  # sent you an email.
  credentials = build_service(get_credentials())
  messages = ListMessagesMatchingQuery(credentials, "me")
  emailCounts = {}
  user = GetMessage(credentials, "me", messages[0]['id'])['payload']['headers'][0]['value']
  length = len(messages)
  for i in range(min(length, 100)):
      curr = GetMessage(credentials, "me", messages[i]['id'])
      index = indexInMessage(curr['payload']['headers'], "From")
      sender = curr['payload']['headers'][index]['value']
      if "<" in sender:
        sender = sender[sender.index("<")+1:sender.index(">")].lower()
      if not sender == user:
        try:
          emailCounts[sender] = emailCounts[sender] + 1
        except KeyError:
          emailCounts.update({sender: 1})

  # Determines the sender who has sent you the most emails, as well as that maximum number of emails.
  def findMaxSender():
    return max(emailCounts, key=emailCounts.get)

  # Sorts emailCounts dictionary by number of emails sent
  def sortedEmails():
    return sorted(emailCounts.items(), key=operator.itemgetter(1), reverse = True)

  # Gets a list of the top 20% of senders by number of emails sent
  def findTopFifth():
    topFifth = {}
    numTopFifth = len(emailCounts)//5
    topFifth = sortedEmails()[0:numTopFifth]
    return topFifth

  # Sums the total number of emails that the top 20% of senders have sent you
  def sumTopFifth():
    sumTopFifthCounts = 0
    for i in range(len(emailCounts)//5):
      sumTopFifthCounts += findTopFifth()[i][1]
    return sumTopFifthCounts

  # Sums the total number of emails in your inbox
  def sumEmails():
    totalEmails = 0
    for i in range(len(sortedEmails())):
      totalEmails += sortedEmails()[i][1]
    return totalEmails

  # Calculates the percentage of your inbox that is occupied by messages sent by the top fifth of senders
  def findPercentTopFifth():
    percentOccupiedByTopFifth = float(sumTopFifth())/sumEmails() * 100
    return round(percentOccupiedByTopFifth, 2)

  # Finds the average size of all messages in inbox in bytes
  def findAverageSizeOfMessageInBytes(): 
    totalSize = 0.0
    for i in range(min(100, len(messages))):
      curr = GetMessage(credentials, "me", messages[i]['id'])
      totalSize += curr['sizeEstimate']
    averageSize = float(totalSize)/sumEmails()
    return averageSize

  # Finds the average size of all messages in inbox in kilobytes
  def findAverageSizeOfMessageInKB():
    return round(findAverageSizeOfMessageInBytes()/1024, 2)

  # Displays in bar chart who the top 20% of senders are with the associated number
  # of emails they have sent
  def graphTopFifthSenders():
    topFifth = findTopFifth()
    counts = []
    senders = []
    value = str(random.randint(1000000, 10000000))
    for i in range(len(topFifth)):
      counts.append(topFifth[i][1])
      senders.append(topFifth[i][0])
    xpos = range(len(senders))
    plt.bar(xpos, counts, align='center', alpha=0.5)
    plt.xticks(xpos, senders, rotation=90)
    plt.ylabel('Number of Emails')
    plt.title('Email Counts for Top 20 percent of Senders')
    plt.tight_layout()
    plt.savefig('/finalproject/static/figureTopFifth' + value + '.png')
    plt.clf() 
    return '/static/figureTopFifth' + value + '.png'

  # Displays in bar chart who the top 20% of senders are with the associated percent
  # of total Inbox their emails occupy
  def graphTopFifthSendersWithPercent():
    topFifth = findTopFifth()
    counts2 = []
    senders = []
    value = str(random.randint(1000000, 10000000))
    for i in range(len(topFifth)):
      counts2.append(float(topFifth[i][1])/sumEmails()*100)
      senders.append(topFifth[i][0])
    xpos2 = range(len(senders)) #####
    plt.bar(xpos2, counts2, align='center', alpha=0.5)
    plt.xticks(xpos2, senders, rotation=90)
    plt.ylabel('Percent of Total Inbox')
    plt.title('Email Percents for Top 20 percent of Senders')
    plt.tight_layout()
    plt.savefig('/finalproject/static/figureTopFifthPercent' + value + '.png')
    plt.clf() 
    return '/static/figureTopFifthPercent' + value + '.png'

  # Displays in bar chart the amount of your inbox occupied by the top 20% of senders
  # compared to what the 80/20 rule predicts
  def graphPercentTopFifthAndEighty():
    counts3 = [80, findPercentTopFifth()]
    senders = ["80/20 rule", "Your Inbox"]
    value = str(random.randint(1000000, 10000000))
    xpos3 = range(len(senders))
    plt.bar(xpos3, counts3, align='center', alpha=0.5)
    plt.xticks(xpos3, senders, rotation=90)
    plt.ylabel('Percentage')
    plt.title('Does your Inbox follow the 80-20 Rule?')
    plt.tight_layout()
    plt.savefig('/finalproject/static/figure8020' + value + '.png')
    plt.clf() 
    return '/static/figure8020' + value + '.png'
  return render_template("datavis.html", pctTopFifth = findPercentTopFifth(), img1 = graphPercentTopFifthAndEighty(), img2 = graphTopFifthSendersWithPercent(), img3 = graphTopFifthSenders(), avgsize = findAverageSizeOfMessageInKB(), maxsender = findMaxSender(), totalemails = sumEmails())

# Determines what to do after the request
@app.after_request
def after_request(response):
  response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
  response.headers["Expires"] = 0
  response.headers["Pragma"] = "no-cache"
  return response

# Executes the main method
if __name__ == '__main__':
  # When running locally, disable OAuthlib's HTTPs verification.
  # ACTION ITEM for developers:
  #     When running in production *do not* leave this option enabled.
  os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

  # Specify a hostname and port that are set as a valid redirect URI
  # for your API project in the Google API Console.
  app.jinja_env.auto_reload = True
  app.run('localhost', 8080, debug=True, use_reloader = True)